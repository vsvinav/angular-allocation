enum Technology {
    JAVA,
    PYTHON,
    JS
}
export default Technology;
