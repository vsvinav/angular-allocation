import Technology from './Technology';
export class Project {
    id: number;
    name: string;
    basedTechnology: Technology[];


}
